# Micro Frontend Service UI — Developer README

This document explains how to build a **body/content panel** for one service (e.g. `UserService`, `CatalogService`, `ReportService`) that plugs into a shared Shell application via **Webpack Module Federation**.

---

## Architecture Overview

```
Shell App (Host)                         http://localhost:3000
├── <Header />         ← owned by Shell (logo, nav links, user avatar)
├── <Sidebar />        ← owned by Shell (context-aware left nav)
└── <ContentArea />    ← dynamically loads THIS service's <App />
         │
         └── userService/App    ← YOU BUILD THIS   http://localhost:3001
```

The Shell loads your component **at runtime** using `React.lazy()` + `Suspense`. Your service runs as its own dev server and exposes a single React component as a remote module.

---

## What You Build (Your Responsibility)

You only build the **body/content panel** — everything inside the white area on the right side of the screen.

```
┌──────────────────────────────────────────────────────┐
│  HEADER  (Shell owns this — do not duplicate)        │
├────────────┬─────────────────────────────────────────┤
│            │                                         │
│  SIDEBAR   │   👉 YOUR SERVICE UI GOES HERE          │
│  (Shell    │                                         │
│   owns     │   - Build as a normal React app         │
│   this)    │   - Use full width/height of this area  │
│            │   - Receive props from Shell if needed  │
│            │                                         │
└────────────┴─────────────────────────────────────────┘
```

### Do NOT include in your service:
- ❌ A top `<Header>` or `<Navbar>` component
- ❌ A `<Sidebar>` or left navigation panel
- ❌ `<html>`, `<body>`, or full-page layout wrappers
- ❌ Global auth logic (Shell handles login/logout)

### DO include in your service:
- ✅ Your feature UI (tables, forms, dashboards, etc.)
- ✅ Internal routing within your section (React Router sub-routes)
- ✅ Your own API calls and local state
- ✅ Loading and error states within the content area

---

## Project Setup

### 1. Create the App

```bash
npx create-react-app user-service
cd user-service
npm install webpack webpack-cli webpack-dev-server @module-federation/vite
```

Or with Vite:

```bash
npm create vite@latest user-service -- --template react
npm install @originjs/vite-plugin-federation
```

---

### 2. Configure Module Federation

#### Option A — Webpack (`webpack.config.js`)

```js
const { ModuleFederationPlugin } = require('webpack').container;
const deps = require('./package.json').dependencies;

module.exports = {
  mode: 'development',
  devServer: { port: 3001 },   // ← Each service gets a unique port
  plugins: [
    new ModuleFederationPlugin({
      name: 'userService',          // ← unique name per service
      filename: 'remoteEntry.js',   // ← Shell loads this file
      exposes: {
        './App': './src/App',       // ← Expose your root component
      },
      shared: {
        react: { singleton: true, requiredVersion: deps.react },
        'react-dom': { singleton: true, requiredVersion: deps['react-dom'] },
      },
    }),
  ],
};
```

#### Option B — Vite (`vite.config.js`)

```js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import federation from '@originjs/vite-plugin-federation';

export default defineConfig({
  plugins: [
    react(),
    federation({
      name: 'userService',
      filename: 'remoteEntry.js',
      exposes: { './App': './src/App' },
      shared: ['react', 'react-dom'],
    }),
  ],
  server: { port: 3001 },
  preview: { port: 3001 },
});
```

---

### 3. Build Your App Component (`src/App.jsx`)

Your `App.jsx` is what the Shell will mount. It should behave as a self-contained content panel.

```jsx
// src/App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import UserList from './pages/UserList';
import UserDetail from './pages/UserDetail';

/**
 * Props injected by the Shell:
 * @param {Object}  currentUser   - Logged-in user object { id, name, role, token }
 * @param {string}  basePath      - Base URL path for this service e.g. "/users"
 * @param {Function} onNavigate   - Navigate to another service: onNavigate('catalog')
 */
export default function App({ currentUser, basePath = '/users', onNavigate }) {
  return (
    <div style={{ padding: '1.5rem', height: '100%', overflowY: 'auto' }}>
      <Routes>
        <Route path={basePath} element={<UserList currentUser={currentUser} />} />
        <Route path={`${basePath}/:id`} element={<UserDetail />} />
      </Routes>
    </div>
  );
}
```

> **Note:** The Shell wraps the entire app with `<BrowserRouter>`, so you do NOT add a Router here — just use `<Routes>`.

---

### 4. Register Your Service in the Shell

Tell the Shell team to add your remote in their `webpack.config.js` or `vite.config.js`:

```js
// Shell's webpack.config.js — Shell team adds this
remotes: {
  userService: 'userService@http://localhost:3001/remoteEntry.js',
},
```

And in the Shell's routing:

```jsx
const UserApp = React.lazy(() => import('userService/App'));

// Inside Shell's <ContentArea />:
<Suspense fallback={<Spinner />}>
  <UserApp currentUser={currentUser} basePath="/users" onNavigate={setActiveModule} />
</Suspense>
```

---

## Props Contract (Shell → Your Service)

These props are passed from the Shell into your `App` component. Handle them gracefully (default values / optional chaining).

| Prop | Type | Description |
|---|---|---|
| `currentUser` | `Object` | `{ id, name, email, role, token }` — the logged-in user |
| `basePath` | `string` | Base URL prefix for your routes e.g. `"/users"` |
| `onNavigate` | `Function` | Call to switch to another service: `onNavigate('catalog')` |
| `theme` | `Object` | (optional) `{ primaryColor, fontFamily }` for consistent styling |

---

## Cross-Service Communication (Events)

To communicate between services without tight coupling, use a shared event bus:

```js
// Use the shared eventBus published by the Shell (imported as a singleton)
import { emit, on } from 'shell/eventBus';   // Shell exposes this

// Emit an event (e.g. after a user is updated)
emit('user:updated', { id: 42, name: 'Jane' });

// Listen for events from other services
on('catalog:itemSelected', (item) => {
  console.log('Catalog selected:', item);
});
```

---

## Styling Guidelines

- **Do NOT set** `body`, `html`, or `#root` styles — Shell controls these.
- **Do NOT import** global CSS resets.
- Use **CSS Modules**, **Tailwind**, or **styled-components** scoped to your component.
- Respect the Shell's CSS variables for brand consistency (Shell will document these):

```css
/* Available CSS variables from Shell */
--color-primary: #1e40af;
--color-bg: #f8fafc;
--color-text: #1e293b;
--font-base: 'Inter', sans-serif;
--sidebar-width: 240px;
--header-height: 60px;
```

---

## Running Locally (Standalone)

Your service can run independently for development:

```bash
npm start          # Starts on port 3001
```

For standalone testing, wrap `<App />` in a mock shell layout:

```jsx
// src/index.jsx (local dev entry — not exposed to Shell)
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

const mockUser = { id: 1, name: 'Dev User', role: 'admin', token: 'dev-token' };

ReactDOM.render(
  <BrowserRouter>
    <App currentUser={mockUser} basePath="/" />
  </BrowserRouter>,
  document.getElementById('root')
);
```

---

## Service Port Registry

Ensure each service uses a unique port to avoid conflicts:

| Service | Port | Remote URL |
|---|---|---|
| Shell (Host) | 3000 | — |
| UserService | 3001 | `http://localhost:3001/remoteEntry.js` |
| CatalogService | 3002 | `http://localhost:3002/remoteEntry.js` |
| ReportService | 3003 | `http://localhost:3003/remoteEntry.js` |
| RatingsService | 3004 | `http://localhost:3004/remoteEntry.js` |
| AdminService | 3005 | `http://localhost:3005/remoteEntry.js` |

---

## Deployment

Each service is deployed independently. The Shell only needs the URL to your `remoteEntry.js` in production:

```js
// Shell production config
remotes: {
  userService: 'userService@https://user-service.mycompany.com/remoteEntry.js',
}
```

Update this URL whenever your service is deployed to a new host.

---

## Checklist Before Handoff to Shell Team

- [ ] `remoteEntry.js` is accessible at `http://localhost:{PORT}/remoteEntry.js`
- [ ] `./App` is exposed in Module Federation config
- [ ] `App` accepts `currentUser`, `basePath`, `onNavigate` props
- [ ] No global layout (header/sidebar/html/body) in your component
- [ ] Runs standalone without the Shell for local development
- [ ] CSS is scoped — no global style pollution
- [ ] React and React-DOM are declared as `shared` singletons
- [ ] Port is registered in the Port Registry above

---

## Questions?

Contact the Shell team or refer to the main architecture repo for:
- Shell's `eventBus` API reference
- Available CSS variables
- Auth token refresh strategy
- Shared component library (buttons, modals, tables)