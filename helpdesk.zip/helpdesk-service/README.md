# HelpDesk Service

<div align="start">
<img src="./resources/images/golang.png" alt="Go Logo" width="200"/>
</div>

## Overview

HelpDesk Service is a production-ready Go microservice that provides two core capabilities:

1. **Ratings** — Users can rate any entity (product, service, order, etc.) identified by a type and entity ID. Each rating captures the user, the score (configurable scale, e.g. 1–5 or 1–10), and an optional comment. Admins (or the entity owner) can reply to any rating — especially useful for acknowledging poor feedback.
2. **Issue Reporting & Threaded Conversations** — Users can report issues against any entity. Admins and users exchange replies in a threaded conversation until the issue is marked resolved or closed.

The service exposes both gRPC and HTTP/REST APIs, follows clean architecture principles, and is designed to be embedded into any platform as a standalone microservice.

## Features

- 🚀 **Dual Protocol Support**: Both gRPC and HTTP/REST APIs with gRPC-Gateway
- 🏗️ **Clean Architecture**: Well-organized project structure following Go best practices
- 📋 **Protocol Buffers**: Type-safe API definitions with Buf-powered code generation
- 🔧 **Configuration Management**: YAML-based configuration with environment support
- 📊 **Structured Logging**: Comprehensive logging with configurable levels
- 🔍 **Debug Support**: Built-in debugging endpoints and pprof integration
- 🐳 **Docker Ready**: Complete containerization with multi-stage builds
- 🧪 **Testing Framework**: Ready-to-use testing setup
- 📚 **API Documentation**: Auto-generated Swagger/OpenAPI documentation
- 🛡️ **Graceful Shutdown**: Proper application lifecycle management
- 🔌 **Repository Pattern**: Pluggable data layer with memory implementation
- 🎯 **Middleware Support**: HTTP middleware for cross-cutting concerns
- 🛠️ **Modern Tooling**: Uses Buf for efficient Protocol Buffer management
- ⭐ **Ratings Engine**: Configurable rating scale per entity type
- 💬 **Rating Replies**: Admins or entity owners can respond to ratings (e.g. acknowledge poor feedback)
- 🗨️ **Threaded Issue Conversations**: Multi-turn admin/user dialogue until resolution

## Project Structure

```
go-base-service/
├── api/                          # API definitions and generated code
│   ├── buf.yaml                 # Buf configuration for Proto management
│   ├── buf.gen.yaml            # Buf code generation configuration
│   ├── buf.lock                # Buf dependency lock file
│   ├── protoc.sh               # Proto compilation script using Buf
│   ├── proto/                  # Protocol Buffer definitions
│   │   ├── common/            # Shared proto messages
│   │   └── helpdesk/v1/ # Service-specific protos
│   ├── helpdesk_v1/      # Generated Go code from protos
│   └── docs/                  # Generated API documentation
├── cmd/                         # Application entry points
│   ├── grpc_server/            # gRPC server implementation
│   └── http_server/            # HTTP server implementation  
├── internal/                    # Private application code
│   ├── configs/                # Configuration management
│   ├── constants/              # Application constants
│   ├── models/                 # Data models and DTOs
│   ├── repository/             # Data access layer
│   └── service/                # Business logic layer
├── pkg/                        # Public libraries
│   ├── debug/                  # Debug utilities
│   └── utils/                  # Common utilities
├── migrations/                 # SQL migration files (golang-migrate format)
│   ├── 000001_create_ratings.{up,down}.sql
│   ├── 000002_create_rating_replies.{up,down}.sql
│   ├── 000003_create_issues.{up,down}.sql
│   └── 000004_create_issue_replies.{up,down}.sql
├── resources/                  # Static resources
├── dev.yaml                    # Development configuration
├── Dockerfile                  # Container build instructions
├── Makefile                    # Build and development commands
└── main.go                     # Application bootstrap
```

## Quick Start

### Prerequisites

- Go 1.23.3 or later
- Buf CLI (`buf`) - Modern Protocol Buffer toolchain
- Docker (optional, for containerized deployment)

### Installation

1. **Clone or use this template:**
   ```bash
   git clone <your-repo-url>
   cd go-base-service
   ```

2. **Install dependencies and tools:**
   ```bash
   make install
   ```

3. **Generate API code from Protocol Buffers using Buf:**
   ```bash
   make setup
   ```

4. **Run the service:**
   ```bash
   make run
   ```

The service will start with both servers:
- HTTP Server: `http://localhost:8085`
- gRPC Server: `localhost:8086`

### Testing the Service

**Health check:**

```bash
# HTTP endpoint
curl http://localhost:8085/helpdesk/v1/ping

# Response
{"message": "Its fine here...!"}
```

**Submit a rating:**
```bash
curl -X POST http://localhost:8085/helpdesk/v1/ratings \
  -H 'Content-Type: application/json' \
  -d '{
    "user_id": "user-123",
    "type": "product",
    "entity_id": "product-456",
    "rating": 4,
    "comment": "Great product!"
  }'
```

**Report an issue:**
```bash
curl -X POST http://localhost:8085/helpdesk/v1/issues \
  -H 'Content-Type: application/json' \
  -d '{
    "user_id": "user-123",
    "type": "order",
    "entity_id": "order-789",
    "title": "Item not delivered",
    "description": "My order was supposed to arrive yesterday."
  }'
```

**Reply to an issue (admin):**
```bash
curl -X POST http://localhost:8085/helpdesk/v1/issues/{id}/replies \
  -H 'Content-Type: application/json' \
  -d '{
    "user_id": "admin-001",
    "role": "admin",
    "message": "We are looking into this and will update you shortly."
  }'
```

## API Reference

### Ratings

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/helpdesk/v1/ratings` | Submit a new rating for an entity |
| `GET` | `/helpdesk/v1/ratings` | List ratings (filterable by `type`, `entity_id`, `user_id`) |
| `GET` | `/helpdesk/v1/ratings/{id}` | Get a specific rating by ID |
| `PUT` | `/helpdesk/v1/ratings/{id}` | Update a rating (owner only) |
| `DELETE` | `/helpdesk/v1/ratings/{id}` | Delete a rating (owner or admin) |

#### Rating Model

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Unique identifier |
| `user_id` | string | ID of the user who rated |
| `type` | string | Entity type (e.g. `product`, `order`, `service`) |
| `entity_id` | string | ID of the entity being rated |
| `rating` | int32 | Score value (validated against configured max scale) |
| `comment` | string | Optional free-text comment |
| `created_at` | timestamp | Creation time |
| `updated_at` | timestamp | Last update time |

> **Rating scale** is configurable per deployment (e.g. 1–5 or 1–10) via `dev.yaml`.

---

### Rating Replies

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/helpdesk/v1/ratings/{id}/replies` | Post a reply to a rating |
| `GET` | `/helpdesk/v1/ratings/{id}/replies` | List all replies for a rating |
| `DELETE` | `/helpdesk/v1/ratings/{id}/replies/{reply_id}` | Delete a reply (owner or admin) |

#### Rating Reply Model

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Unique identifier |
| `rating_id` | string | Parent rating ID |
| `user_id` | string | ID of the replier |
| `role` | enum | `user` \| `admin` |
| `message` | string | Reply text |
| `created_at` | timestamp | Creation time |

> Typically only one reply per rating is expected (e.g. an admin acknowledgement), but the model supports multiple replies to allow follow-up.

---

### Issues

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/helpdesk/v1/issues` | Report a new issue |
| `GET` | `/helpdesk/v1/issues` | List issues (filterable by `type`, `entity_id`, `user_id`, `status`) |
| `GET` | `/helpdesk/v1/issues/{id}` | Get a specific issue with its conversation thread |
| `PUT` | `/helpdesk/v1/issues/{id}` | Update issue metadata or status |
| `DELETE` | `/helpdesk/v1/issues/{id}` | Delete an issue (admin only) |

#### Issue Model

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Unique identifier |
| `user_id` | string | ID of the user who reported the issue |
| `type` | string | Entity type (e.g. `product`, `order`, `service`) |
| `entity_id` | string | ID of the entity the issue relates to |
| `title` | string | Short title of the issue |
| `description` | string | Detailed description |
| `status` | enum | `open` \| `in_progress` \| `resolved` \| `closed` |
| `created_at` | timestamp | Creation time |
| `updated_at` | timestamp | Last update time |

#### Issue Status Transitions

```
open ──► in_progress ──► resolved ──► closed
  └──────────────────────────────────────────►
```

---

### Issue Replies (Conversations)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/helpdesk/v1/issues/{id}/replies` | Add a reply to an issue thread (user or admin) |
| `GET` | `/helpdesk/v1/issues/{id}/replies` | List all replies for an issue in chronological order |

#### Reply Model

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Unique identifier |
| `issue_id` | string | Parent issue ID |
| `user_id` | string | ID of the replier |
| `role` | enum | `user` \| `admin` |
| `message` | string | Reply text |
| `created_at` | timestamp | Creation time |

> An issue moves to `resolved` when an admin explicitly updates its status. Both admin and user can continue replying on a resolved issue (e.g. to confirm resolution), after which it can be `closed`.

---

## Configuration

The service uses YAML configuration files. The default `dev.yaml` includes:

```yaml
Logger:
  AppName: helpdesk
  Level: debug
AppNames:
  - HTTP_SERVER
  - GRPC_SERVER
Server:
  GRPCPort: 8086
  HTTPPort: 8085
Repository:
  Name: memory
Debug:
  Enabled: true
  EnablePprof: true
Ratings:
  MaxScale: 5   # Maximum allowed rating value (e.g. 5 or 10)
```

### Configuration Options

- **Logger**: Logging configuration (app name, level, format)
- **AppNames**: List of servers to start (HTTP_SERVER, GRPC_SERVER)
- **Server**: Port configurations for both servers
- **Repository**: Data layer configuration
- **Debug**: Debug and profiling settings
- **Ratings.MaxScale**: Upper bound of the rating scale (default `5`); ratings submitted above this value are rejected

## Development

### Adding New Endpoints

1. **Define the service in Protocol Buffers:**
   ```protobuf
   // api/proto/helpdesk/v1/helpdesk.proto
   service HelpdeskService {
       rpc YourNewMethod (YourRequest) returns (YourResponse) {
           option (google.api.http) = {
               post: "/helpdesk/v1/your-endpoint"
               body: "*"
           };
       }
   }
   ```

2. **Add message definitions:**
   ```protobuf
   // api/proto/common/your_messages.proto
   message YourRequest {
       string field = 1;
   }
   
   message YourResponse {
       string result = 1;
   }
   ```

3. **Regenerate code using Buf:**
   ```bash
   make setup
   ```

4. **Implement the service method:**
   ```go
   // internal/service/your_service.go
   func (s *Service) YourNewMethod(ctx context.Context, req *helpdesk_v1.YourRequest) (*helpdesk_v1.YourResponse, error) {
       // Your business logic here
       return &helpdesk_v1.YourResponse{
           Result: "success",
       }, nil
   }
   ```

### Available Make Commands

```bash
make build        # Build the application binary
make build-linux  # Build for Linux (useful for Docker)
make run          # Run the application locally
make test         # Run all tests
make clean        # Clean build artifacts
make docker       # Build Docker image
make docker-run   # Build and run in Docker container
make install      # Install dependencies and tools
make setup        # Generate code from protobuf definitions using Buf
```

### Repository Layer

The service includes a pluggable repository pattern. Currently implements:

- **Memory Repository**: In-memory storage for development/testing

To add new repository implementations:

1. Create a new package under `internal/repository/`
2. Implement the `service.Repository` interface
3. Register it in `repository.go`

### Adding Middleware

HTTP middleware can be added in `pkg/utils/middleware.go`:

```go
func YourMiddleware() func(http.Handler) http.Handler {
    return func(next http.Handler) http.Handler {
        return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
            // Your middleware logic
            next.ServeHTTP(w, r)
        })
    }
}
```

## Database Migrations

Migrations live in `migrations/` and follow the [golang-migrate](https://github.com/golang-migrate/migrate) naming convention (`{version}_{title}.{up|down}.sql`).

### Schema Overview

| # | File | Table | Purpose |
|---|------|-------|---------|
| 1 | `000001_create_ratings` | `ratings` | Stores user ratings for any entity |
| 2 | `000002_create_rating_replies` | `rating_replies` | Admin/owner responses to ratings |
| 3 | `000003_create_issues` | `issues` | Helpdesk issues reported by users |
| 4 | `000004_create_issue_replies` | `issue_replies` | Threaded conversation on issues |

### Running Migrations

```bash
# Install golang-migrate CLI (once)
brew install golang-migrate

# Apply all pending migrations
migrate -path ./migrations \
        -database "postgres://user:password@localhost:5432/helpdesk?sslmode=disable" \
        up

# Roll back the last applied migration
migrate -path ./migrations \
        -database "postgres://user:password@localhost:5432/helpdesk?sslmode=disable" \
        down 1

# Roll back all migrations
migrate -path ./migrations \
        -database "postgres://user:password@localhost:5432/helpdesk?sslmode=disable" \
        down
```

### Key Design Decisions

- **`gen_random_uuid()`** — requires PostgreSQL 13+ (or the `pgcrypto` extension on older versions).
- **Timestamps as `BIGINT` (epoch milliseconds)** — `created_at` and `updated_at` store Unix time in milliseconds (`(EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT`). This avoids timezone handling complexity and maps directly to `int64` in Go and JavaScript `Date.now()`.
- **Unique constraint on `ratings`** — `(user_id, type, entity_id)` ensures one rating per user per entity.
- **No foreign keys** — `rating_replies.rating_id` and `issue_replies.issue_id` are plain `UUID` columns with no FK constraint, keeping writes fast. Referential integrity is enforced at the application layer.
- **`issue_status` enum** — enforces valid transitions at the DB level (`open` | `in_progress` | `resolved` | `closed`).
- **`rating_reply_role` / `issue_reply_role` enums** — restrict repliers to known roles (`user` | `admin`).

## Deployment

### Docker Deployment

```bash
# Build and run with Docker
make docker-run
```

The container exposes:
- Port 8085: HTTP API
- Port 8086: gRPC API

### Production Considerations

1. **Configuration**: Use environment-specific YAML files
2. **Logging**: Configure appropriate log levels for production
3. **Monitoring**: Add health checks and metrics endpoints
4. **Security**: Implement authentication and authorization
5. **Database**: Replace memory repository with persistent storage

## API Documentation

When running the service, Swagger documentation is available at:
- `http://localhost:8085/helpdesk/v1/swagger`

### Authentication

The API uses header-based authentication with the following headers:

- **`x-user-id`**: The user identifier (required for all authenticated endpoints)
- **`x-user-perms`**: Comma-separated list of user permissions (e.g., `"issue:reply,rating:reply"`)

In Swagger UI, you can set these headers by:
1. Clicking the "Authorize" button at the top of the page
2. Entering the header values in the security scheme dialog
3. The headers will be automatically included in all API requests

**Example permissions:**
- `issue:reply` - Can reply to issues
- `rating:reply` - Can reply to ratings  
- `issue:update:status` - Can update issue status
- `delete:any` - Can delete any content

## Dependencies

### Core Dependencies
- **gofreego/goutils**: Utilities for configuration, logging, and application lifecycle
- **grpc-ecosystem/grpc-gateway**: HTTP/gRPC gateway for dual protocol support
- **google.golang.org/grpc**: gRPC framework
- **google.golang.org/protobuf**: Protocol Buffers support

### Development Tools
- **buf**: Modern Protocol Buffer toolchain for compilation and dependency management
- **protoc-gen-go**: Go code generator for protobuf
- **protoc-gen-grpc-gateway**: HTTP gateway generator

## Buf Configuration

The project uses Buf for Protocol Buffer management with the following configuration:

### `api/buf.yaml`
- Defines the module configuration
- Sets up linting rules using DEFAULT ruleset
- Configures breaking change detection
- Declares dependency on `googleapis/googleapis`

### `api/buf.gen.yaml` 
- Configures code generation plugins:
  - `go`: Generates Go structs from proto messages
  - `go-grpc`: Generates gRPC service interfaces
  - `grpc-gateway`: Generates HTTP/REST gateway code
  - `openapiv2`: Generates Swagger/OpenAPI documentation

### `api/protoc.sh`
- Shell script that runs `buf dep update` and `buf generate`
- Executed by `make setup` command

## Contributing

1. Follow the existing code structure and patterns
2. Add tests for new functionality
3. Update documentation as needed
4. Ensure all make commands pass successfully

## License

This project is licensed under the terms specified in the LICENSE file.

## Getting Help

This template provides a solid foundation for Go microservices. For specific implementation questions:

1. Check the existing code examples in the `internal/service` package
2. Review the Protocol Buffer definitions in `api/proto`
3. Examine the server implementations in `cmd/`

## Domain Model Summary

```
┌──────────────────────────────────────────────────────┐
│                     Rating                           │
│  id · user_id · type · entity_id · rating · comment  │
│                                                      │
│  ┌───────────────────────────────────────────────┐  │
│  │                 Rating Reply                  │  │
│  │  id · rating_id · user_id · role · message    │  │
│  └───────────────────────────────────────────────┘  │
│  (one rating ──► many replies, ordered by created_at)│
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│                      Issue                           │
│  id · user_id · type · entity_id · title ·           │
│  description · status (open/in_progress/             │
│                        resolved/closed)              │
│                                                      │
│  ┌───────────────────────────────────────────────┐  │
│  │                    Reply                      │  │
│  │  id · issue_id · user_id · role · message     │  │
│  └───────────────────────────────────────────────┘  │
│  (one issue ──► many replies, ordered by created_at) │
└──────────────────────────────────────────────────────┘
```

## Next Steps

1. **Implement Rating proto messages and service methods** for CRUD operations
2. **Implement Rating Reply proto messages and service methods** for acknowledging/responding to ratings
3. **Implement Issue proto messages and service methods** for CRUD + status transitions
4. **Implement Issue Reply proto messages and service methods** for threaded conversations
5. **Configure data storage**: Replace the memory repository with a persistent database (e.g. PostgreSQL)
6. **Add authentication**: ✅ Implemented header-based auth with `x-user-id` and `x-user-perms` headers
7. **Pagination**: Apply cursor-based or offset pagination on all list endpoints
8. **Notifications**: Emit events when an issue receives a new reply, a rating receives a response, or an issue changes status
8. **Set up CI/CD**: Configure your deployment pipeline
9. **Add monitoring**: Integrate with your observability stack
